# Prigod Idle press kit

Last audited: 2026-08-18 against game build `0.9.0.140`.

This is the central source for press, creator, and store-facing material. Remaining
pre-publication items are listed at the bottom; everything else is ready to use.

## Quick facts

| Field | Current answer |
|---|---|
| Title | **Prigod Idle** |
| Developer | **Prigod Games** *(name used in the Steam-page draft; confirm before publication)* |
| Publisher | **Prigod Games** *(self-published; confirm before publication)* |
| Genre | Idle / incremental RPG, auto-battler, character-building game |
| Players | Single-player, with optional PvP modes |
| Status | Pre-release; Steam launch date to be announced |
| Announced Steam platform | Windows PC, 64-bit |
| Other working builds | Web/browser; mobile is in development |
| Planned price | **US$6.99** |
| Business model | Premium, one-time purchase; no microtransactions, ads, or battle pass |
| Languages | English, German, French, Spanish, Brazilian Portuguese, Russian, Simplified Chinese |
| Engine | Godot 4.6 |
| Current build | `0.9.0.140` |
| Press contact | prigodgames@gmail.com |
| Website | https://prigodgames.github.io/PrigodGames/ |
| Steam page (full game) | https://store.steampowered.com/app/5091900 *(URL fixed by App ID; resolves once the page is public)* |
| Steam page (demo) | https://store.steampowered.com/app/5091970 *(same)* |
| Release date/window | October 2026 |

## One-sentence pitch

**Prigod Idle is a fantasy idle auto-battle RPG where heroes fight for you, but every victory comes from the build you create.**

## Short description

Build a hero and send it to battle to fight for you. An idle auto-battler RPG where strategizing with your build is fun and meaningful. Combine gear, gems, relics, pets and tech trees, counter strange bosses, participate in multiple minigames and progress offline. Pay once, no ads, no daily chores.

*(This is the live Steam short description; all seven language versions with verified ≤300-character counts are in [`docs/steam-page-localized.md`](../../docs/steam-page-localized.md).)*

## Boilerplate

Prigod Idle is a 2D fantasy idle auto-battle RPG about building a combat machine that feels distinctly yours. Choose a hero, equipment, abilities, gems, relics, pets, enchantments, tech upgrades, and a route through card-draft runs, then watch the build meet monsters and bosses in automated combat. When progress stalls, the answer is a new plan rather than a purchase. Beyond the campaign, players can explore prestige and Ascension, dungeons, crafting, housing, pet battles, optional PvP, rotating events, and more than twenty no-reflex minigames. Prigod Idle is designed as a premium game with offline progress and hundreds of hours of build experimentation, without microtransactions, advertisements, or a battle pass.

## Key features

- **Auto-battles with meaningful preparation.** Heroes fight automatically; equipment, abilities, gems, relics, pets, enchants, tech trees, combos, and route choices determine how they fight.
- **Dozens of viable build identities.** Crit, combo, DoT, curse, summon, tank, thorns, charge, healer, elemental, and hybrid approaches can be rebuilt whenever a new wall demands it.
- **Active runs and real idle progress.** Card-draft adventures provide decisions while offline generators continue producing resources when the game is closed.
- **A broad collection to experiment with.** The current data includes 37 heroes, 68 named relics, 47 pets, and 23 Fables, plus a large pool of abilities, gems, gear, and cosmetics. *(Counts verified against game data at `0.9.0.140`.)*
- **Long-term progression.** Grow a World Tree through prestige, unlock automation, and eventually raise progression caps through Ascension.
- **Side systems with mechanical rewards.** Dungeons, crafting, housing, pet battles, the Gem Mine, achievements, Colosseum modes, and other activities feed back into character progression.
- **Ten rotating events and 22 minigames.** Logic, deduction, programming, and press-your-luck diversions avoid reaction-time tests while still awarding useful progression.
- **Premium by design.** No microtransactions, paid currency, advertisements, battle pass, or timers intended to sell a shortcut.

## Suggested tags

`Idle` · `Incremental` · `RPG` · `Auto Battler` · `Loot` · `Character Customization` · `Strategy` · `Casual` · `Singleplayer` · `2D`

## Ready-to-use visual assets

### Logo and key art

| Purpose | Asset | Size / format |
|---|---|---|
| Transparent wordmark | [library_logo.png](../steam/library_logo.png) | 1280×720 PNG with transparency |
| Application icon | [app_icon.png](../../assets/app_icon.png) | 256×256 PNG |
| General key art | [main_capsule.png](../steam/main_capsule.png) | 1232×706 PNG |
| Wide hero art | [library_hero.png](../steam/library_hero.png) | 3840×1240 PNG |
| Portrait key art | [vertical_capsule.png](../steam/vertical_capsule.png) | 748×896 PNG |

The remaining Steam-specific capsule sizes are indexed in [the Steam checklist](../../tools/steam/CHECKLIST.md).

### Recommended screenshot set

These are all clean 2560×1440 compositions. The order below leads with gameplay, then demonstrates build depth and breadth.

1. [Boss fight](../steam/screenshots/01_boss_fight.png) — immediate combat and character art.
2. [Hero roster](../steam/screenshots/03_heroes.png) — build variety and progression.
3. [Gem Forge](../steam/screenshots/08_gemforge.png) — collection and build customization.
4. [World Tree](../steam/screenshots/05_world_tree.png) — prestige and long-term progression.
5. [Dungeons](../steam/screenshots/07_dungeons.png) — breadth of combat challenges.
6. [Pets](../steam/screenshots/04_pets.png) — collectible companion roster.
7. [Housing](../steam/screenshots/11_housing.png) — connected side systems.
8. [Spring Bloom](../steam/screenshots/12_spring_bloom.png) — event-minigame variety.

Additional desktop screenshots are available in [`marketing/steam/screenshots`](../steam/screenshots/), and 1080×1920 originals are available in [`marketing/mobile/screenshots`](../mobile/screenshots/).

### Animated loops (GIF / MP4)

Eleven gameplay loops live in [`marketing/social/gifs`](../social/gifs/) (build_the_answer, buildcraft_gear, change_the_gear, choose_your_route, combat_boss, fast_gear_swaps, minigames, route_equal_fight, runs_on_the_side, tech_tree, twenty_heroes). They embed on the website's game page and can be re-encoded to MP4 for platforms that reject GIFs: `ffmpeg -i x.gif -pix_fmt yuv420p -crf 24 x.mp4`.

## Trailer

- Final public trailer: [`marketing/trailer/prigod_trailer_v4.mp4`](../trailer/prigod_trailer_v4.mp4) (85 s, 1920×1080, 60 fps).
- Thumbnail: [`trailer_thumbnail.png`](trailer_thumbnail.png) (1920×1080 — the opening dragon fight with the wordmark).
- Video poster: [`trailer_poster.jpg`](trailer_poster.jpg) (1280×720, same frame without the wordmark; this is the file the website's `<video poster>` uses).
- Both are rebuilt from the trailer by [`tools/art/trailer_thumbnail.py`](../../tools/art/trailer_thumbnail.py). Pick a frame where the enemy is **not** mid hit-flash — the flash tints the sprite flat red and erases its outlines, which is what made the dragon read as a red blob in the first cut.
- Script and shot list: [trailer-script-v4.md](../trailer/trailer-script-v4.md).
- Before publishing, re-verify the end card's claims (demo/Steam availability) against what is actually live that day.

## Useful coverage angles

- An idle game whose monetization model deliberately rejects the genre's usual microtransactions and ads.
- Automated combat built around player-authored builds rather than passive stat growth alone.
- A large collection of interconnected progression systems in a solo-developed Godot project.
- Twenty-two event minigames designed around logic and decision-making rather than reflexes.
- A mobile-shaped interface presented cleanly on desktop through composed widescreen framing.

## Media and creator policy

You are welcome to publish articles, reviews, screenshots, videos, streams, and other
coverage of Prigod Idle — including **monetized** videos and streams — using footage,
screenshots you capture, and the assets supplied in this kit. No prior permission is
needed. Please do not sell the supplied assets themselves, present modified assets as
official, or imply that Prigod Games endorses your content or product. For interview
requests, preview keys, or anything not covered here: **prigodgames@gmail.com**.

No generated visual assets ship in the game: every shipped asset is either original or
licensed. Some third-party assets require attribution in the game's credits; that
obligation is the developer's, not the press's.

## System requirements (draft — confirm before publication)

| | Minimum | Recommended |
|---|---|---|
| OS | Windows 10 64-bit | Windows 10/11 64-bit |
| Processor | Dual-core 2 GHz | Quad-core |
| Memory | 4 GB RAM | 8 GB RAM |
| Graphics | Direct3D 12 / Vulkan-capable GPU | Dedicated GPU |
| Storage | 1 GB | 1 GB |

These are engine-typical values for a 2D Godot 4.6 title and have not yet been verified
on low-end hardware. Confirm (especially the GPU floor) before they go on the store page.

## Distribution

- The kit is packaged for the website with [`tools/art/make_presskit.py`](../../tools/art/make_presskit.py),
  which zips this README (as `factsheet.md`), the logo/key-art set, the eight recommended
  screenshots, and the trailer thumbnail into `marketing/press-kit/prigod-idle-presskit.zip`
  (the trailer is linked, not bundled, to keep the download small). The zip is generated,
  not committed — rebuild it after any asset change.
- Publish the kit page + zip on the website once the Steam page is public, so the store
  links resolve. Until then this kit is internal.
- No social channels exist yet (website + Steam only). If channels are created, add them
  to Quick facts and the website footer together.

## Developer Info

My name is Nicolas, I have a masters degree in Data Science and one of my greatest hobbies is creating games! Prigod Idle is the first game to come out of my one person indie studio based in Germany!

## Internal sources

- Shipped-art provenance: [`docs/art-provenance.csv`](../../docs/art-provenance.csv)
- Store copy: [`docs/steam-page.md`](../../docs/steam-page.md) · localized store copy: [`docs/steam-page-localized.md`](../../docs/steam-page-localized.md)
- Launch decisions and open items: [`docs/launch-checklist.md`](../../docs/launch-checklist.md)
- Game and feature design: [`Prigodot_Idle_Design.md`](../../Prigodot_Idle_Design.md)
- Current version and storefront routing: [`scripts/data/GameInfo.gd`](../../scripts/data/GameInfo.gd)
- Export targets: [`export_presets.cfg`](../../export_presets.cfg)
