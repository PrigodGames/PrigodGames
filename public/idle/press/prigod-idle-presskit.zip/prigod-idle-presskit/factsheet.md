# Prigod Idle press kit

Last audited: 2026-08-27 against game build `0.9.0.194`.

This is the central source for press, creator, and store-facing material. Remaining
pre-publication items are listed at the bottom; everything else is ready to use.

## Quick facts

| Field | Current answer |
|---|---|
| Title | **Prigod Idle** |
| Developer / Publisher | **Prigod Games** |
| Genre | Idle / incremental RPG, auto-battler, character-building game |
| Players | Single-player, with optional leaderboards |
| Status | Pre-release; store page and free demo live since 22 Aug 2026 |
| Platforms | Windows PC 64-bit (Steam) · Android (Google Play) |
| Demo | Free, on the same Steam page as the full game |
| Price | **US$6.99**, Steam regional pricing, 10% launch discount |
| Business model | Premium, one-time purchase with no microtransactions |
| Languages | English, German, French, Spanish, Brazilian Portuguese, Russian, Simplified Chinese (more after launch if players ask) |
| Engine | Godot 4.6 |
| Current build | `0.9.0.194` |
| Press contact | press@prigodgames.de |
| Website | https://prigodgames.github.io/PrigodGames/ |
| Trailer | https://www.youtube.com/watch?v=OnoZA0FQGnw |
| YouTube channel | https://www.youtube.com/channel/UCVSV0YmzzZ9FsAHlgoLDjHg |
| TikTok | https://www.tiktok.com/@prigod.games |
| Steam page (full game) | https://store.steampowered.com/app/5091900/Prigod_Idle/ *(live — wishlist and free demo)* |
| Steam developer page | https://store.steampowered.com/dev/PrigodGames |
| Steam community group | https://steamcommunity.com/groups/PrigodGames |
| Release date | **4 November 2026** — Steam and Google Play, same day |

## One-sentence pitch

**Build a hero. Send it to battle. Outbuild everything in your way.**

*(This is the live store tagline. Keep the page and the store saying the same thing.)*

## Short description

Build a hero and send them to battle to fight for you! An idle auto-battler RPG where strategizing with your build is fun and meaningful. Combine gear, gems, relics, pets and tech trees, counter strange bosses, participate in multiple minigames and progress offline. Pay once, no ads or microtransactions.

*(Press-kit copy. At 305 characters, this version is five characters over Steam's 300-character limit; the storefront-localized versions remain in [`docs/steam-page-localized.md`](../../docs/steam-page-localized.md).)*

## Boilerplate

Prigod Idle is a 2D fantasy idle auto-battler. You pick the hero, the gear, the abilities, the gems, the relics, the pets and the route. Your hero does the fighting. When an enemy seems to be too strong, change your build to overcome it! Besides the campaign stages there is prestige, Ascension, dungeons, crafting, housing, pet battles, ten events and 22 minigames. Pay once, play forever without microtransactions.

## Key features

- **Your build does the fighting.** Heroes attack on their own. Gear, abilities, gems, relics, pets, enchants, tech trees and combos decide how.
- **37 heroes, and they do not play alike.** Every one has its own animations and kit.
- **Builds worth naming.** Crit, combo, DoT, curse, summon, tank, thorns, charge, healer, elemental. Swap to any of them the moment a wall says you should.
- **Runs you steer, progress you do not babysit.** Pick a route and pick your fights. Generators keep paying out while the game is closed.
- **A lot to collect.** 68 relics whose abilities stay on the relic, 42 pets with rolled stats, 23 Fables, plus gems, gear and cosmetics.
- **Four tech trees and six prestige branches.** Reset a run, grow the World Tree, then raise the caps themselves with Ascension.
- **Ten events and 22 minigames.** Dig for gems, brew potions, drop Plinko chips, deduce a hidden fleet. None of them test reflexes. All of them pay progression.
- **One purchase, and that is it.** Gems are earned. Energy paces runs, it does not sell refills. No ads, no battle pass.

## Store description

*(This is the long description the Steam page runs. Press can reprint it as is.)*

Prigod Idle is an idle auto-battler RPG. You equip the gear and abilities, your hero does the fighting. Craft a build from gear, gems, relics and four tech trees, then watch it carve through monsters, bosses and rival champions.

**THE HERO FIGHTS. YOUR BUILD DECIDES.**

- 37 heroes, and every one of them plays differently
- Gear with sockets, enchants and set-defining relic abilities
- 68 relics, 42 pets and 23 legendary Fables to collect
- Four tech trees and six prestige branches to shape long-term power

**READ THE BOSS. BUILD THE ANSWER.**

- A long campaign with special bosses and unique boss mechanics
- Dungeons, Peril tiers, a recurring World Boss and the PvP Colosseum
- A route map every run: pick your path, your fights and your rewards

**EARN YOUR BUILD IN FIGHTS AND MINIGAMES**

- 10 events with exclusive heroes and gear
- 22 minigames: dig for gems, brew potions, drop Plinko chips, and many more
- Build out your homestead, get pets, and fill the Prigod Dex

**NO INGAME STORE. OFFLINE PROGRESSION. PLAY IT FULLY IDLE IF YOU WANT**

- Full offline progress, including offline dungeon clears
- Gems are earned by playing. No ads, no energy walls, no microtransactions

**YOUR DESKTOP COMPANION**

- Runs on the side while you do other things
- Prestige unlocks new modules for automation
- A compact portrait window that fits beside anything

Try the free demo! Your demo progress carries into the full game.

## Demo

The demo is the real game up to stage 4, with its own save. Demo progress carries into
the full game. The full game adds the rest of the campaign and its difficulty tiers,
prestige, the World Tree and Ascension, every rotating event with its minigames and
event heroes, the Colosseum and the arena tree, housing, crafting, the Gem Mine and
commissions, Fables, pets and pet battles, the complete hero and relic roster, and the
Hardcore and other pace modes.

## Suggested tags

`Idle` · `Incremental` · `RPG` · `Auto Battler` · `Loot` · `Character Customization` · `Strategy` · `Casual` · `Singleplayer` · `2D`

## Ready-to-use visual assets

### Logo and key art

| Purpose | Asset | Size / format |
|---|---|---|
| Transparent wordmark | [library_logo.png](../steam/library_logo.png) | 1280×720 PNG with transparency |
| Application icon | [app_icon.png](../../assets/app_icon.png) | 256×256 PNG |
| General key art | [main_capsule.png](../steam/CapsuleArt/main_capsule.png) | 1232×706 PNG |
| Wide hero art | [library_hero.png](../steam/CapsuleArt/library_hero.png) | 3840×1240 PNG |
| Portrait key art | [vertical_capsule.png](../steam/CapsuleArt/vertical_capsule.png) | 748×896 PNG |

The remaining Steam-specific capsule sizes are indexed in [the Steam checklist](../../tools/steam/CHECKLIST.md).

### Recommended screenshot set

These are all clean 2560×1440 compositions. The order leads with three real desktop-panel layouts, then demonstrates gameplay, build depth and breadth.

1. [Desktop panels](../steam/screenshots/15_desktop_panes.png) — Home between the Idle generators and a full gear bag.
2. [Desktop tech and codex](../steam/screenshots/16_desktop_tech_codex.png) — browse the relic codex and tech tree alongside the main game.
3. [Desktop chests and bag](../steam/screenshots/17_desktop_bag_chests.png) — open chests and inspect a full gear bag without leaving Home.
4. [Boss fight](../steam/screenshots/01_boss_fight.png) — immediate combat and character art.
5. [Hero roster](../steam/screenshots/03_heroes.png) — build variety and progression.
6. [Gem Forge](../steam/screenshots/08_gemforge.png) — collection and build customization.
7. [World Tree](../steam/screenshots/05_world_tree.png) — prestige and long-term progression.
8. [Spring Bloom](../steam/screenshots/12_spring_bloom.png) — event-minigame variety.
9. [Bull Rush interrupted](../social/screenshots/bull_rush_interrupted_1920x1080.jpg) — the Minotaur's visible boss windup denied by a control build.
10. [Auto-run](../social/screenshots/auto_run_1920x1080.jpg) — the full-idle switch armed on Stage Select.

Additional desktop screenshots are available in [`marketing/steam/screenshots`](../steam/screenshots/), and 1080×1920 originals are available in [`marketing/mobile/screenshots`](../mobile/screenshots/).

### Animated loops (GIF / MP4)

Eleven gameplay loops live in [`marketing/social/gifs`](../social/gifs/) (build_the_answer, buildcraft_gear, change_the_gear, choose_your_route, combat_boss, fast_gear_swaps, minigames, route_equal_fight, runs_on_the_side, tech_tree, twenty_heroes). They embed on the website's game page and can be re-encoded to MP4 for platforms that reject GIFs: `ffmpeg -i x.gif -pix_fmt yuv420p -crf 24 x.mp4`.

## Trailer

- **Watch it:** https://www.youtube.com/watch?v=OnoZA0FQGnw (published 2026-08-23). This is the URL to quote in
  coverage; the local file below is for editors who want the clean source.

- Final public trailer: [`marketing/trailer/prigod_trailer_v4.mp4`](../trailer/prigod_trailer_v4.mp4) (85 s, 1920×1080, 60 fps).
- Thumbnail: [`trailer_thumbnail.png`](trailer_thumbnail.png) (1920×1080 — the opening dragon fight with the wordmark).
- Video poster: [`trailer_poster.jpg`](trailer_poster.jpg) (1280×720, same frame without the wordmark; this is the file the website's `<video poster>` uses).
- Both are rebuilt from the trailer by [`tools/art/trailer_thumbnail.py`](../../tools/art/trailer_thumbnail.py). Pick a frame where the enemy is **not** mid hit-flash — the flash tints the sprite flat red and erases its outlines, which is what made the dragon read as a red blob in the first cut.
- Script and shot list: [trailer-script-v4.md](../trailer/trailer-script-v4.md).
- Before publishing, re-verify the end card's claims (demo/Steam availability) against what is actually live that day.

## Useful coverage angles

- An idle game with long-term progression without microtransactions.
- Combat you win at the build screen instead of by tapping.
- One developer, many ideas and a lot of systems wired into each other.
- 22 minigames built on logic and decisions rather than reflexes.
- Use a small portrait interface to play it on the side or use full screen with extra panels.

## Media and creator policy

Publish what you like. Articles, reviews, screenshots, videos, streams, monetized or
not. Use the assets here or capture your own. You do not need to ask first.

Two limits. Do not sell the supplied assets themselves, and do not present edited
assets as official or imply that Prigod Games endorses your video or your product.

Want an interview, a preview key, or something this page does not cover? Write to
**press@prigodgames.de**.

No generated visual assets ship in the game. Some third-party art needs attribution in
the credits screen. That is the developer's job, not yours.

## System requirements

| | Minimum | Recommended |
|---|---|---|
| OS | Windows 10 64-bit | Windows 10/11 64-bit |
| Processor | Dual-core 2 GHz | Quad-core |
| Memory | 4 GB RAM | 8 GB RAM |
| Graphics | DirectX 12 GPU with feature level 12_0 | Dedicated GPU |
| Storage | 2 GB available space | 2 GB available space |

The Windows build renders through **Direct3D 12** (`rendering_device/driver.windows="d3d12"`
in `project.godot`), not Vulkan. Godot 4's Windows renderers require **feature level 12_0**
([Godot system requirements](https://docs.godotengine.org/en/stable/about/system_requirements.html)), which is the
real floor — it is stricter than "Vulkan 1.0" and rules out pre-2016 GPUs. The engine
confirms the level at startup ("D3D12 12_0 - Forward Mobile").

The CPU / RAM / storage rows have not been measured on low-end hardware; treat them as a
floor to verify, not a tested result.

## Distribution

- The kit is packaged for the website with [`tools/art/make_presskit.py`](../../tools/art/make_presskit.py),
  which zips this README (as `factsheet.md`), the logo/key-art set, the ten recommended
  screenshots, and the trailer thumbnail into `marketing/press-kit/prigod-idle-presskit.zip`
  (the trailer is linked, not bundled, to keep the download small). The zip is generated,
  not committed — rebuild it after any asset change.
- The kit page and zip are published on the website (live since 22 Aug 2026), so the store
  links resolve.
- Social channels are live: YouTube and TikTok, both in Quick facts above. The demo has no
  store page of its own — it lives on the full game's page, so **never link the demo app id
  publicly**; it redirects to the Steam home page.

## Developer Info

My name is Nicolas, I have a masters degree in Data Science and one of my greatest hobbies is creating games! Prigod Idle is the first game to come out of my one person indie studio based in Germany!

## Internal sources

- Shipped-art provenance: [`docs/art-provenance.csv`](../../docs/art-provenance.csv)
- Store copy: [`docs/steam-page.md`](../../docs/steam-page.md) · localized store copy: [`docs/steam-page-localized.md`](../../docs/steam-page-localized.md)
- Launch decisions and open items: [`docs/launch-checklist.md`](../../docs/launch-checklist.md)
- Game and feature design: [`Prigodot_Idle_Design.md`](../../Prigodot_Idle_Design.md)
- Current version and storefront routing: [`scripts/data/GameInfo.gd`](../../scripts/data/GameInfo.gd)
- Export targets: [`export_presets.cfg`](../../export_presets.cfg)
