# Prigod Idle press kit

Last audited: 2026-08-18 against game build `0.9.0.140`.

This is the central source for press, creator, and store-facing material. Remaining
pre-publication items are listed at the bottom; everything else is ready to use.

## Quick facts

| Field | Current answer |
|---|---|
| Title | **Prigod Idle** |
| Developer | **Prigod Games** *(name used in the Steam-page draft; confirm before publication)* |
| Publisher | **Prigod Games** *(self-published; confirm before publication)* |
| Genre | Idle / incremental RPG, auto-battler, character-building game |
| Players | Single-player, with optional PvP modes |
| Status | Pre-release; Steam launch date to be announced |
| Announced Steam platform | Windows PC, 64-bit |
| Other working builds | Web/browser; mobile is in development |
| Planned price | **US$6.99** |
| Business model | Premium, one-time purchase; no microtransactions, ads, or battle pass |
| Languages | English, German, French, Spanish, Brazilian Portuguese, Russian, Simplified Chinese |
| Engine | Godot 4.6 |
| Current build | `0.9.0.140` |
| Press contact | prigodgames@gmail.com |
| Website | https://prigodgames.github.io/PrigodGames/ |
| Steam page (full game) | https://store.steampowered.com/app/5091900 *(URL fixed by App ID; resolves once the page is public)* |
| Steam page (demo) | https://store.steampowered.com/app/5091970 *(same)* |
| Release date/window | October 2026 |

## One-sentence pitch

**Build a hero. Send it to battle. Outbuild everything in your way.**

*(This is the live store tagline. Keep the page and the store saying the same thing.)*

## Short description

Build a hero and send it to battle to fight for you. An idle auto-battler RPG where strategizing with your build is fun and meaningful. Combine gear, gems, relics, pets and tech trees, counter strange bosses, participate in multiple minigames and progress offline. Pay once, no ads, no daily chores.

*(This is the live Steam short description; all seven language versions with verified ≤300-character counts are in [`docs/steam-page-localized.md`](../../docs/steam-page-localized.md).)*

## Boilerplate

Prigod Idle is a 2D fantasy idle auto-battler. You pick the hero, the gear, the
abilities, the gems, the relics, the pets and the route. The hero does the fighting.
When a boss stops you, the fix is a new build, not a bigger wallet. Past the campaign
there is prestige, Ascension, dungeons, crafting, housing, pet battles, PvP, ten
rotating events and 22 minigames. You buy the game once. Gems are earned by playing.
No ads, no battle pass, no timers built to sell you a shortcut.

## Key features

- **Your build does the fighting.** Heroes attack on their own. Gear, abilities, gems, relics, pets, enchants, tech trees and combos decide how.
- **37 heroes, and they do not play alike.** Every one has its own animations and kit.
- **Builds worth naming.** Crit, combo, DoT, curse, summon, tank, thorns, charge, healer, elemental. Swap to any of them the moment a wall says you should.
- **Runs you steer, progress you do not babysit.** Pick a route and pick your fights. Generators keep paying out while the game is closed.
- **A lot to collect.** 68 relics whose abilities stay on the relic, 47 pets with rolled stats, 23 Fables, plus gems, gear and cosmetics. *(Counts verified against game data at `0.9.0.140`.)*
- **Four tech trees and six prestige branches.** Reset a run, grow the World Tree, then raise the caps themselves with Ascension.
- **Ten events and 22 minigames.** Dig for gems, brew potions, drop Plinko chips, deduce a hidden fleet. None of them test reflexes. All of them pay progression.
- **One purchase, and that is it.** Gems are earned. Energy paces runs, it does not sell refills. No ads, no battle pass.

## Store description

*(This is the long description the Steam page runs. Press can reprint it as is.)*

Build a hero. Send it to battle. Outbuild everything in your way.

Prigod Idle is an idle auto-battler RPG. You equip the gear and abilities, your hero does the fighting. Craft a build from gear, gems, relics and four tech trees, then watch it carve through monsters, bosses and rival champions.

**Your build does the fighting**

- 37 heroes, and every one of them plays differently
- Gear with sockets, enchants and set-defining relic abilities
- 68 relics, 47 pets and 23 legendary Fables to collect
- Four tech trees and six prestige branches to shape long-term power

**Fights that fight back**

- Lots of different enemies with unique strengths
- A campaign with special bosses and unique boss mechanics
- Dungeons, Peril tiers, a recurring World Boss and the PvP Colosseum
- A route map every run: pick your path, your fights and your rewards

**More things to discover**

- 10 events with exclusive heroes and gear
- 22 minigames: dig for gems, brew potions, drop Plinko chips, and many more
- Build out your homestead, get pets, and fill the Prigod Dex

**Autobattle meets idle progress**

- Full offline progress, including offline dungeon clears
- Gems are earned by playing. No ads, no energy walls, no microtransactions

Try the free demo. Your demo progress carries into the full game.

## Demo

The demo is the real game up to stage 20, with its own save. Demo progress carries into
the full game. The full game adds the rest of the campaign and its difficulty tiers,
prestige, the World Tree and Ascension, every rotating event with its minigames and
event heroes, the Colosseum and the arena tree, housing, crafting, the Gem Mine and
commissions, Fables, pets and pet battles, the complete hero and relic roster, and the
Hardcore and other pace modes.

## Suggested tags

`Idle` · `Incremental` · `RPG` · `Auto Battler` · `Loot` · `Character Customization` · `Strategy` · `Casual` · `Singleplayer` · `2D`

## Ready-to-use visual assets

### Logo and key art

| Purpose | Asset | Size / format |
|---|---|---|
| Transparent wordmark | [library_logo.png](../steam/library_logo.png) | 1280×720 PNG with transparency |
| Application icon | [app_icon.png](../../assets/app_icon.png) | 256×256 PNG |
| General key art | [main_capsule.png](../steam/main_capsule.png) | 1232×706 PNG |
| Wide hero art | [library_hero.png](../steam/library_hero.png) | 3840×1240 PNG |
| Portrait key art | [vertical_capsule.png](../steam/vertical_capsule.png) | 748×896 PNG |

The remaining Steam-specific capsule sizes are indexed in [the Steam checklist](../../tools/steam/CHECKLIST.md).

### Recommended screenshot set

These are all clean 2560×1440 compositions. The order below leads with gameplay, then demonstrates build depth and breadth.

1. [Boss fight](../steam/screenshots/01_boss_fight.png) — immediate combat and character art.
2. [Hero roster](../steam/screenshots/03_heroes.png) — build variety and progression.
3. [Gem Forge](../steam/screenshots/08_gemforge.png) — collection and build customization.
4. [World Tree](../steam/screenshots/05_world_tree.png) — prestige and long-term progression.
5. [Dungeons](../steam/screenshots/07_dungeons.png) — breadth of combat challenges.
6. [Pets](../steam/screenshots/04_pets.png) — collectible companion roster.
7. [Housing](../steam/screenshots/11_housing.png) — connected side systems.
8. [Spring Bloom](../steam/screenshots/12_spring_bloom.png) — event-minigame variety.

Additional desktop screenshots are available in [`marketing/steam/screenshots`](../steam/screenshots/), and 1080×1920 originals are available in [`marketing/mobile/screenshots`](../mobile/screenshots/).

### Animated loops (GIF / MP4)

Eleven gameplay loops live in [`marketing/social/gifs`](../social/gifs/) (build_the_answer, buildcraft_gear, change_the_gear, choose_your_route, combat_boss, fast_gear_swaps, minigames, route_equal_fight, runs_on_the_side, tech_tree, twenty_heroes). They embed on the website's game page and can be re-encoded to MP4 for platforms that reject GIFs: `ffmpeg -i x.gif -pix_fmt yuv420p -crf 24 x.mp4`.

## Trailer

- Final public trailer: [`marketing/trailer/prigod_trailer_v4.mp4`](../trailer/prigod_trailer_v4.mp4) (85 s, 1920×1080, 60 fps).
- Thumbnail: [`trailer_thumbnail.png`](trailer_thumbnail.png) (1920×1080 — the opening dragon fight with the wordmark).
- Video poster: [`trailer_poster.jpg`](trailer_poster.jpg) (1280×720, same frame without the wordmark; this is the file the website's `<video poster>` uses).
- Both are rebuilt from the trailer by [`tools/art/trailer_thumbnail.py`](../../tools/art/trailer_thumbnail.py). Pick a frame where the enemy is **not** mid hit-flash — the flash tints the sprite flat red and erases its outlines, which is what made the dragon read as a red blob in the first cut.
- Script and shot list: [trailer-script-v4.md](../trailer/trailer-script-v4.md).
- Before publishing, re-verify the end card's claims (demo/Steam availability) against what is actually live that day.

## Useful coverage angles

- An idle game that sells nothing after the purchase. No ads, no currency packs, no battle pass.
- Combat you win at the build screen instead of by tapping.
- One developer, one Godot project, and a lot of systems wired into each other.
- 22 minigames built on logic and decisions rather than reflexes.
- A portrait interface that sits cleanly on a desktop screen.

## Media and creator policy

Publish what you like. Articles, reviews, screenshots, videos, streams, monetized or
not. Use the assets here or capture your own. You do not need to ask first.

Two limits. Do not sell the supplied assets themselves, and do not present edited
assets as official or imply that Prigod Games endorses your video or your product.

Want an interview, a preview key, or something this page does not cover? Write to
**prigodgames@gmail.com**.

No generated visual assets ship in the game. Some third-party art needs attribution in
the credits screen. That is the developer's job, not yours.

## System requirements

| | Minimum | Recommended |
|---|---|---|
| OS | Windows 10 64-bit | Windows 10/11 64-bit |
| Processor | Dual-core 2 GHz | Quad-core |
| Memory | 4 GB RAM | 8 GB RAM |
| Graphics | Vulkan 1.0 compatible GPU | Dedicated GPU |
| Storage | 2 GB available space | 2 GB available space |

These mirror the live Steam page. They have not been measured on low-end hardware, so
treat the minimum column as a floor to verify, not a tested result.

## Distribution

- The kit is packaged for the website with [`tools/art/make_presskit.py`](../../tools/art/make_presskit.py),
  which zips this README (as `factsheet.md`), the logo/key-art set, the eight recommended
  screenshots, and the trailer thumbnail into `marketing/press-kit/prigod-idle-presskit.zip`
  (the trailer is linked, not bundled, to keep the download small). The zip is generated,
  not committed — rebuild it after any asset change.
- Publish the kit page + zip on the website once the Steam page is public, so the store
  links resolve. Until then this kit is internal.
- No social channels exist yet (website + Steam only). If channels are created, add them
  to Quick facts and the website footer together.

## Developer Info

My name is Nicolas, I have a masters degree in Data Science and one of my greatest hobbies is creating games! Prigod Idle is the first game to come out of my one person indie studio based in Germany!

## Internal sources

- Shipped-art provenance: [`docs/art-provenance.csv`](../../docs/art-provenance.csv)
- Store copy: [`docs/steam-page.md`](../../docs/steam-page.md) · localized store copy: [`docs/steam-page-localized.md`](../../docs/steam-page-localized.md)
- Launch decisions and open items: [`docs/launch-checklist.md`](../../docs/launch-checklist.md)
- Game and feature design: [`Prigodot_Idle_Design.md`](../../Prigodot_Idle_Design.md)
- Current version and storefront routing: [`scripts/data/GameInfo.gd`](../../scripts/data/GameInfo.gd)
- Export targets: [`export_presets.cfg`](../../export_presets.cfg)
